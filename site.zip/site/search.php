<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search results</title>
    <meta charset="utf-8">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
    <meta name="description" content="Your description">
    <meta name="keywords" content="Your keywords">
    <meta name="author" content="Your name">    
    <link rel="stylesheet" href="css/bootstrap.css" >
    <link rel="stylesheet" href="css/responsive.css" >
    <link rel="stylesheet" href="css/style.css" >
		<script src="js/jquery.js"></script>
        <script src="js/jquery.easing.1.3.js"></script>
        <script src="js/jquery-migrate-1.1.1.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/jquery.mobilemenu.js"></script>
         
        <script src="search/search.js"></script>      
      <!--[if lt IE 8]>
          <div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg"border="0"alt=""/></a></div>  
      <![endif]-->
  <!--[if lt IE 9]>
  
    <link rel="stylesheet" href="css/ie.css" >
    <script src="assets/js/html5shiv.js"></script>
  <![endif]-->
</head>
<body>    
  <header>  
  	<div>
        <div class="container">
          <div class="row">
            <div class="span12 clearfix">
              <div class="navbar navbar_ clearfix">
                <div class="navbar-inner">                                                 
                  <div class="nav-collapse nav-collapse_ collapse">
                    <ul class="nav sf-menu clearfix">
                      <li><a href="index.html">Home</a></li>
                      <li class="sub-menu"><a href="index-1.html">about</a>
                      	<ul>
                          <li><a href="#">about</a></li>
                          <li><a href="#">team</a></li>
                          <li><a href="#">events</a></li>
                          <li><a href="#">news</a></li>
                          <li><a href="#">gallery</a></li>
                        </ul>
                      </li>
                      <li><a href="index-2.html">gallery</a></li>
                      <li><a href="index-3.html">Blog</a></li>
                      <li><a href="index-4.html">mail us</a></li>
                    </ul>
                  </div>
                </div>
              </div> 
            </div> 
          </div> 
       </div>  
    </div>  
  </header>
  <!--==============================content=================================-->
<div class="shadow"> 
<div class="shadow-2"> 
  <div id="content">
    <div class="container">
    	<div class="row header-block">
        	<div class="span3">
            	<ul class="soc-icons">
                    <li><a href="#"><img src="img/icon-1.png" alt=""></a></li>
					<li><a href="#"><img src="img/icon-2.png" alt=""></a></li>
                    <li><a href="#"><img src="img/icon-3.png" alt=""></a></li>
                    <li><a href="#"><img src="img/icon-4.png" alt=""></a></li>
                    <li><a href="#"><img src="img/icon-5.png" alt=""></a></li>
                </ul>
             </div>   
            <div class="span6 clearfix center">
              <h1 class="brand"><a href="index.html">aquarium</a></h1> 
            </div> 
            <div class="span3 addr">8901 Marmora Road,<br>
Glasgow, D04 89GR.<br>
phone:  +1 800 559 6580</div>   
      </div> 
      <div class="row">
          <div class="span12">
              <h2>Search result:</h2>
              <div id="search-results"></div>
          </div>
      </div>      
    </div>
  </div> 
</div>
</div>  
<!--==============================footer=================================-->
  <footer>
  	<div class="container">
    	<div class="row">
        	<div class="span12 center"><a href="#" class="footer-email">mail@demolink.org</a><span class="footer-phone">+1 800 559 6580</span></div>
        </div> 
        <div class="row">
        	<div class="span12 center"><em>lorem ipsum dolor sit amet consectetuer adipiscing elit</em></div>
        </div>  
     	<div class="row">
        	<div class="span12 center"><h1 class="brand"><a href="index.html">aquarium</a></h1></div> 
       	</div> 
        <div class="row">
        	<div class="span12 center">aquarium &copy; 2013 &bull; <a href="index-5.html">Privacy Policy</a></div>
       	</div>  
    </div>
 </footer>
<script src="js/bootstrap.js"></script>
</body>
</html>